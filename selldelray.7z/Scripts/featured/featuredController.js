function FeaturedController($scope) {
    $scope.title = "Featured Controller";
    $scope.message = "Featured Controller Message";
}