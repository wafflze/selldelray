function AboutController($scope) {
    $scope.title = "About Controller";
    $scope.message = "About Controller Message";
}