function SearchController($scope) {
    $scope.title = "Search Controller";
    $scope.message = "Search Controller Message";
}