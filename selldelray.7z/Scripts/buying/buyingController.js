function BuyingController($scope) {
    $scope.title = "Buying Controller";
    $scope.message = "Buying Controller Message";
}