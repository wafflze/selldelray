function SellingController($scope) {
    $scope.title = "Selling Controller";
    $scope.message = "Selling Controller Message";
}