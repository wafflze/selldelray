function ContactController($scope) {
    $scope.title = "Contact Controller";
    $scope.message = "Contact Controller Message";
}