function BlogController($scope) {
    $scope.title = "Blog Controller";
    $scope.message = "Blog Controller Message";
}