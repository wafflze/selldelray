function HomeController($scope) {
    $scope.title = "Home Controller";
    $scope.message = "Home Controller Message";
}